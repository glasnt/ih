# ih

A very persuasive package, for creating embroidery patterns. 

[As seen at PyCon US 2019](https://us.pycon.org/2019/schedule/presentation/229/)

## Package name origin

Disney's [_Lilo and Stitch_](https://www.youtube.com/watch?v=ItYmxezZ7QA): 

> Jumba: What?! After all you put me through you expect me to help you just like that?! Just like that?!
> Stitch: Ih.
> Jumba: Fine.
> Pleakley: Fine? You're doing what he says?
> Jumba: Uh, he's very persuasive.


