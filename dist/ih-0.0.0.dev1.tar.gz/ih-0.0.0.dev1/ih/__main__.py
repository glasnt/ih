from ih.chart import *

def main():
    chart()
