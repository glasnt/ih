import setuptools

with open("README.md", "r") as f:
    long_description = f.read()

with open("requirements.txt", "r") as f: 
    requirements = f.read()

setuptools.setup(
    name="ih",
    version="0.0.0-dev1",
    author="katie McLaughlin",
    author_email="katie@glasnt.com",
    description="A very persuasive package, for creating embroidery patterns",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/glasnt/ih",
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            "ih = ih.__main__:main"
        ]
    },
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: BSD License",
    ],
)
